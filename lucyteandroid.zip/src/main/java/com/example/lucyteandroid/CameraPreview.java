package com.example.lucyteandroid;

import static android.hardware.Camera.Parameters.FOCUS_MODE_INFINITY;
import static android.hardware.Camera.Parameters.SCENE_MODE_ACTION;
import static android.hardware.Camera.Parameters.SCENE_MODE_SPORTS;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.IOException;

public class CameraPreview extends SurfaceView implements SurfaceHolder.Callback {
    private static final String TAG = "CameraPreview" ;
    private SurfaceHolder mHolder;
    private Camera mCamera;
    public CameraPreview(Context context, Camera camera, MyGLRenderer renderer) {
        super(context);
        mCamera = camera;

        // Install a SurfaceHolder.Callback so we get notified when the
        // underlying surface is created and destroyed.
        mHolder = getHolder();
        mHolder.addCallback(this);
        // deprecated setting, but required on Android versions prior to 3.0
        mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        mCamera.setPreviewCallback(new Camera.PreviewCallback() {
            @Override
            public void onPreviewFrame(byte[] data, Camera camera) {
                Camera.Parameters parameters = camera.getParameters();
                Camera.Size size = parameters.getPreviewSize();
                int width = size.width;
                int height = size.height;
                int frameSize = width*height;
                byte[] grey = new byte[frameSize+1];
                // Convert YUV to RGB
                for (int i = 0; i < height; i++) {
                    for (int j = 0; j < width; j++) {
                        int y = (0xff & ((int) data[i * width + j]));
                        //int u = (0xff & ((int) data[frameSize + (i >> 1) * width + (j & ~1) + 0]));
                        //int v = (0xff & ((int) data[frameSize + (i >> 1) * width + (j & ~1) + 1]));
                        y = y < 16 ? 16 : y;
                        //int r = Math.round(1.164f * (y - 16) + 1.596f * (v - 128));
                        //int g = Math.round(1.164f * (y - 16) - 0.813f * (v - 128) - 0.391f * (u - 128));
                        //int b = Math.round(1.164f * (y - 16) + 2.018f * (u - 128));
                        //r = r < 0 ? 0 : (r > 255 ? 255 : r);
                        //g = g < 0 ? 0 : (g > 255 ? 255 : g);
                        //b = b < 0 ? 0 : (b > 255 ? 255 : b);
                        grey[j * height + (height-1-i)] = (byte)((y - 16) & 0xff);
                    }
                }
                renderer.cameraData = grey;
                renderer.cameraWidth = height;
                renderer.cameraHeight = width;
                //Log.d("lucyte","hallo1:" + renderer.cameraWidth + "," + renderer.cameraHeight);
            }
        });
    }

    public void surfaceCreated(SurfaceHolder holder) {
        // The Surface has been created, now tell the camera where to draw the preview.
        try {
            mCamera.setPreviewDisplay(holder);
            mCamera.startPreview();
        } catch (IOException e) {
            Log.d(TAG, "Error setting camera preview: " + e.getMessage());
        }
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        // empty. Take care of releasing the Camera preview in your activity.
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        // If your preview can change or rotate, take care of those events here.
        // Make sure to stop the preview before resizing or reformatting it.

        if (mHolder.getSurface() == null){
            // preview surface does not exist
            return;
        }

        // stop preview before making changes
        try {
            mCamera.stopPreview();
        } catch (Exception e){
            // ignore: tried to stop a non-existent preview
        }

        // set preview size and make any resize, rotate or
        // reformatting changes here

        // start preview with new settings
        try {
            Camera.Parameters mParameters = mCamera.getParameters();
            Camera.Size bestSize = null;

            java.util.List<Camera.Size> sizeList = mCamera.getParameters().getSupportedPreviewSizes();

            double averageM = 0.0;
            for(int i = 0; i < sizeList.size(); i++){
                averageM += sizeList.get(i).width * sizeList.get(i).height;
            }
            averageM /= sizeList.size();
            averageM /= 2;

            double lastDist = 0;
            for(int i = 0; i < sizeList.size(); i++){
                double dist = averageM - (sizeList.get(i).width * sizeList.get(i).height);
                if(i == 0 || dist < lastDist){
                    lastDist = dist;
                    bestSize = sizeList.get(i);
                }
            }

            mParameters.setPreviewSize(bestSize.width, bestSize.height);
            mCamera.setParameters(mParameters);
            mCamera.setPreviewDisplay(mHolder);
            mCamera.startPreview();

        } catch (Exception e){
            Log.d(TAG, "Error starting camera preview: " + e.getMessage());
        }
    }
}