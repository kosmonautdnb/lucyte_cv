package com.example.lucyteandroid;

import static org.opencv.features2d.FastFeatureDetector.TYPE_9_16;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.util.Log;

import org.opencv.core.CvType;
import org.opencv.core.KeyPoint;
import org.opencv.core.Mat;
import org.opencv.core.MatOfKeyPoint;
import org.opencv.features2d.FastFeatureDetector;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MyGLRenderer implements GLSurfaceView.Renderer {

    byte[] cameraData;
    int cameraWidth;
    int cameraHeight;
    int screenWidth;
    int screenHeight;
    boolean init = true;
    int DESCRIPTORUINT32COUNT;
    int KEYPOINTCOUNT = 100;
    int MIPLEVELS = 8;
    float MIPSCALE = 0.5f;
    float ACCEPTABLE_RESAMPLING_ERROR = 10000.0f;
    float ACCEPTABLE_ERROR = 1.0f;
    int descriptors[];
    int resampledDescriptors[];
    float keyPointsX[] = new float[KEYPOINTCOUNT];
    float keyPointsY[] = new float[KEYPOINTCOUNT];
    float keyPointsError[] = new float[KEYPOINTCOUNT];
    int STEPCOUNT = 100;
    float STEPSIZE = 0.002f;
    float SCALEINVARIANCE = 0.5f / 2.f;
    float ROTATIONINVARIANCE = 20.f / 2.f;
    float scaleX = 1.f;
    float scaleY = 1.f;
    FastFeatureDetector FAST;

    MatOfKeyPoint corners;
    List<KeyPoint> cornersAsList;
    Mat img;

    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        // Set the background frame color
        initOpenGL();
        FAST = FastFeatureDetector.create(10, true, TYPE_9_16);
    }

    public void onDrawFrame(GL10 unused) {
        float width = cameraWidth;
        float height = cameraHeight;
        if (cameraData != null) {
            uploadMipMap(0, cameraData, cameraWidth, cameraHeight);
            try {
                img.put( 0, 0, cameraData );
                FAST.detect(img, corners);
                cornersAsList = new LinkedList<KeyPoint>(corners.toList());
            } catch(Exception a) {

            }
            if (init) {
                Log.d("lucyte","Camera preview width:" + cameraWidth + " height:" + cameraHeight);
                init = false;
                for (int i = 0; i < KEYPOINTCOUNT; i++) {
                    keyPointsX[i] = (float)Math.random() * width;
                    keyPointsY[i] = (float)Math.random() * height;
                }
                MIPLEVELS = (int)(Math.floor(Math.log(Math.max(cameraHeight,cameraWidth))/Math.log(1.0/MIPSCALE)))+1;
                DESCRIPTORUINT32COUNT = getDescriptorUint32Count();
                Log.d("test","" + cameraWidth + ":" + cameraHeight + ":" + MIPLEVELS);
                descriptors = new int[KEYPOINTCOUNT*MIPLEVELS*DESCRIPTORUINT32COUNT];
                resampledDescriptors = new int[KEYPOINTCOUNT*MIPLEVELS*DESCRIPTORUINT32COUNT];
                uploadKeyPoints(0, keyPointsX, keyPointsY, KEYPOINTCOUNT);
                sampleDescriptors(0, 0, 0, MIPLEVELS, KEYPOINTCOUNT, DESCRIPTORUINT32COUNT, descriptors, 1.f, MIPSCALE);
                uploadDescriptors( 0,  descriptors, DESCRIPTORUINT32COUNT, KEYPOINTCOUNT, MIPLEVELS);
                scaleX = screenWidth / cameraWidth;
                scaleY = screenHeight / cameraHeight;
                img = new Mat(cameraHeight, cameraWidth, CvType.CV_8UC1);
                corners = new MatOfKeyPoint();
            }
        }
        if (!init) {
            // Redraw background color
            GLES30.glClearColor(0.f, 0.f, 0.f, 1.0f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
            displayMipMap(0, 0, (int)(width * scaleX),(int)(height * scaleY), scaleX, scaleY);
            float[] lastKeyPointsX = keyPointsX.clone();
            float[] lastKeyPointsY = keyPointsY.clone();
            refineKeyPoints(0, 0, 0, MIPLEVELS, KEYPOINTCOUNT, DESCRIPTORUINT32COUNT, STEPCOUNT, MIPSCALE, STEPSIZE, SCALEINVARIANCE, ROTATIONINVARIANCE, keyPointsX, keyPointsY, keyPointsError);
            float r = 8.f;
            float MARGIN = 10.f;
            for (int i = 0; i < KEYPOINTCOUNT; i++) {
                if (keyPointsError[i]>ACCEPTABLE_ERROR||keyPointsX[i]<MARGIN||keyPointsY[i]<MARGIN||keyPointsX[i]>(width-MARGIN)||keyPointsY[i]>(height-MARGIN)) {
                    if (cornersAsList != null) {
                        int l = cornersAsList.size();
                        if (l > 0) {
                            int k = (int) (Math.floor((float) Math.random() * (float) l));
                            KeyPoint kp = cornersAsList.get(k);
                            cornersAsList.remove(k);
                            keyPointsX[i] = (float) kp.pt.x;
                            keyPointsY[i] = (float) kp.pt.y;
                        } else {
                            keyPointsX[i] = (float) Math.random() * width;
                            keyPointsY[i] = (float) Math.random() * height;
                        }
                    }
                } else {
                    drawRectangle(keyPointsX[i]*scaleX - r, keyPointsY[i]*scaleY - r, keyPointsX[i]*scaleX + r, keyPointsY[i]*scaleY + r, 0xff0000ff, (int)(width*scaleX), (int)(height*scaleY));
                    drawLine(keyPointsX[i]*scaleX, keyPointsY[i]*scaleY, lastKeyPointsX[i]*scaleX, lastKeyPointsY[i]*scaleY, 0xffffffff, (int)(width*scaleX), (int)(height*scaleY));
                }
            }
            uploadKeyPoints(0, keyPointsX, keyPointsY, KEYPOINTCOUNT);
            sampleDescriptors(0, 0, 0, MIPLEVELS, KEYPOINTCOUNT, DESCRIPTORUINT32COUNT, resampledDescriptors, 1.f, MIPSCALE);
            for (int i = 0; i < KEYPOINTCOUNT; i++) {
                if (keyPointsError[i] < ACCEPTABLE_RESAMPLING_ERROR) {
                    for (int m = 0; m < MIPLEVELS; m++)
                        for (int j = 0; j < DESCRIPTORUINT32COUNT; j++)
                            descriptors[(m*KEYPOINTCOUNT+i)*DESCRIPTORUINT32COUNT+j] = resampledDescriptors[(m*KEYPOINTCOUNT+i)*DESCRIPTORUINT32COUNT+j];
                }
            }
            uploadDescriptors(0, descriptors, DESCRIPTORUINT32COUNT, KEYPOINTCOUNT, MIPLEVELS);
        }
    }

    public void onSurfaceChanged(GL10 unused, int width, int height) {
        GLES30.glViewport(0, 0, width, height);
        screenWidth = width;
        screenHeight = height;
    }

    public native void initOpenGL();

    public native void uploadMipMap(int mipmapsId, byte[] baseMipMap, int width, int height);

    public native void displayMipMap(int mipmapsId, int mipMap, int screenWidth, int screenHeight, float scaleX, float scaleY);

    public native void uploadKeyPoints(int keyPointsId, float keyPointsX[], float keyPointsY[], int keyPointCount);

    public native void uploadDescriptors(int descriptorsId, int descriptors[], int uint32Count, int keyPointCount, int mipMapCount);

    public native void sampleDescriptors(int keyPointsId, int descriptorsId, int mipmapsId, int mipLevels, int keyPointCount, int uint32Count, int descriptors[], float descriptorScale, float mipScale);

    public native void refineKeyPoints(int keyPointsId, int descriptorsId, int mipmapsId, int mipLevels, int keyPointCount, int uint32Count,  int STEPCOUNT, float MIPSCALE, float STEPSIZE, float SCALEINVARIANCE, float ROTATIONINVARIANCE, float[] keyPointsX, float[] keyPointsY, float[] errors);

    public native void drawRectangle(float x0, float y0, float x1, float y1, int color, int screenWidth, int screenHeight);

    public native void drawLine(float x0, float y0, float x1, float y1, int color, int screenWidth, int screenHeight);

    public native int getDescriptorUint32Count();
}
