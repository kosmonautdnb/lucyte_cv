package com.example.lucyteandroid;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import org.opencv.android.OpenCVLoader;

public class MainActivity extends AppCompatActivity {

    boolean hasCamera;
    Camera camera;

    static {
        System.loadLibrary("lucytelib");
    }

    private MyGLSurfaceView gLView;
    private SurfaceView cameraPreview;

    private static int MY_CAMERA_REQUEST_CODE = 1111;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (OpenCVLoader.initLocal()) {
            Log.d("OpenCV","OpenCV loaded successfully.");
        } else {
            Log.d("OpenCV","OpenCV didn't load.");
        }

        hasCamera = this.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA);
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.CAMERA}, MY_CAMERA_REQUEST_CODE);
        }

        gLView = new MyGLSurfaceView(this);
        camera = camera.open();
        cameraPreview = new CameraPreview(this, camera, gLView.renderer);
        this.setContentView(cameraPreview);
        this.addContentView(gLView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

    }
}